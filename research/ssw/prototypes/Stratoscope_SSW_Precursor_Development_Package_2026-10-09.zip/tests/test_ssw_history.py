"""Pure tests. Live NOAA availability and GRIB metadata still require a workflow run."""
import importlib.util
from datetime import date
from pathlib import Path
import tempfile
import unittest
import numpy as np

spec=importlib.util.spec_from_file_location('ssw_history',Path(__file__).resolve().parents[1]/'scripts'/'prepare-ssw-history.py')
ssw=importlib.util.module_from_spec(spec);spec.loader.exec_module(ssw)


class SswAnalysisTests(unittest.TestCase):
    def inventory(self):
        return '\n'.join([
            '1:0:d=2026100800:HGT:500 mb:anl:',
            '2:500:d=2026100800:UGRD:500 mb:anl:',
            '3:900:d=2026100800:TMP:PV=2e-06 (Km^2/kg/s) surface:anl:',
            '4:1500:d=2026100800:PRES:PV=2e-06 (Km^2/kg/s) surface:anl:',
            '5:2100:d=2026100800:UGRD:PV=2e-06 (Km^2/kg/s) surface:anl:',
        ])

    def test_inventory_exact_analysis_and_ranges(self):
        self.assertEqual(ssw.select_inventory(self.inventory(),date(2026,10,8)),
            {'HGT':(0,500),'TMP':(900,1500),'PRES':(1500,2100)})

    def test_inventory_rejects_wrong_date(self):
        with self.assertRaises(ValueError):ssw.select_inventory(self.inventory(),date(2026,10,7))

    def test_inventory_rejects_missing_or_duplicate_messages(self):
        with self.assertRaises(ValueError):ssw.select_inventory(self.inventory().replace('PRES:PV=2e-06','PRES:PV=-2e-06'),date(2026,10,8))
        with self.assertRaises(ValueError):ssw.select_inventory(self.inventory()+'\n6:2900:d=2026100800:HGT:500 mb:anl:\n7:3600:d=2026100800:TMP:400 mb:anl:',date(2026,10,8))

    def test_potential_temperature(self):
        t=np.array([[260.,270.]])
        p=np.array([[50000.,90000.]])
        theta=ssw.potential_temperature(t,p)
        self.assertAlmostEqual(theta[0,0],260*(2**ssw.R_D_CP),places=7)
        self.assertAlmostEqual(theta[0,1],270*(100000/90000)**ssw.R_D_CP,places=7)

    def test_potential_temperature_rejects_bad_pressure(self):
        with self.assertRaises(ValueError):ssw.potential_temperature(np.array([230.]),np.array([0.]))

    def test_sector_means_area_weighted(self):
        constant=np.full((61,360),42.)
        self.assertEqual(ssw.latitude_weighted_means(constant),{k:42. for k in ssw.SECTORS})
        data=np.tile(np.arange(61,dtype=float)[:,None],(1,360))
        summary=ssw.latitude_weighted_means(data)
        self.assertLess(summary['polar_cap'],summary['europe'])

    def test_polar_map_render(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'map.png'
            ssw.polar_plot(path,np.zeros((61,360)),'h500',date(2026,10,8),Path(tmp)/'missing.json')
            self.assertTrue(path.exists())
            self.assertGreater(path.stat().st_size,1000)

if __name__=='__main__':unittest.main()
