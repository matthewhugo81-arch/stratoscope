import importlib.util
from pathlib import Path
import unittest
import numpy as np

spec=importlib.util.spec_from_file_location('ssw_wave_flux',Path(__file__).resolve().parents[1]/'scripts'/'ssw_wave_flux.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)

class WaveFluxTests(unittest.TestCase):
    def test_wave_1_only(self):
        phase=np.arange(360)*2*np.pi/360
        a=np.broadcast_to(np.sin(phase),(31,91,360)).copy()
        f=mod.decompose_100hpa(a,a)
        for k in ['total','wave1']:
            self.assertTrue(np.allclose(f[k],.5,atol=1e-6))
        for k in ['wave2','higherWavesAndResidual']:
            self.assertTrue(np.allclose(f[k],0,atol=1e-6))

    def test_wave2_negative_with_phase_opposition(self):
        phase=np.arange(360)*2*np.pi/360
        a=np.broadcast_to(np.cos(2*phase),(31,91,360)).copy()
        f=mod.decompose_100hpa(a,-a)
        self.assertTrue(np.allclose(f['total'],-.5,atol=1e-6))
        self.assertTrue(np.allclose(f['wave2'],-.5,atol=1e-6))
        self.assertTrue(np.allclose(f['wave1'],0,atol=1e-6))

    def test_mixed_waves_conserve_total(self):
        phase=np.arange(360)*2*np.pi/360
        v=np.broadcast_to(np.cos(phase)+np.sin(2*phase)+np.sin(3*phase),(31,91,360)).copy()
        t=np.broadcast_to(.5*np.cos(phase)+2*np.sin(2*phase)-np.sin(3*phase),(31,91,360)).copy()
        flux=mod.decompose_100hpa(v,t)
        for i in range(31):
            subtotal=sum(flux[k][i] for k in ['wave1','wave2','higherWavesAndResidual'])
            self.assertAlmostEqual(subtotal,flux['total'][i],places=5)

    def test_incomplete_ensemble_rejected(self):
        with self.assertRaises(ValueError):mod.decompose_100hpa(np.zeros((30,91,360)),np.zeros((30,91,360)))

if __name__=='__main__':unittest.main()
