'use client';
import {useEffect,useState} from 'react';
import {fetchSswHistory,sswHistoryRoot,type SswHistory} from '@/lib/ssw-history';
const format=(v:number|undefined)=>Number.isFinite(v)?`${v! >= 0 ?'+':''}${v!.toFixed(1)} m`:'not shown';
export function SswHistory(){
  const [open,setOpen]=useState(false),[data,setData]=useState<SswHistory|null>(null);
  const [error,setError]=useState(''),[refresh,setRefresh]=useState(0),[selected,setSelected]=useState(6);
  useEffect(()=>{
    if(!open)return;
    const c=new AbortController();setError('');
    void fetchSswHistory(AbortSignal.any([c.signal,AbortSignal.timeout(35000)])).then(d=>{
      if(!c.signal.aborted){setData(d);setSelected(d.analyses.length-1);}
    }).catch(e=>{if(!c.signal.aborted)setError(e.message||'Historical analyses unavailable');});
    return()=>c.abort();
  },[open,refresh]);
  const a=data?.analyses[selected];
  return <div className="glosea-section">
    <button className="glosea-toggle" onClick={()=>setOpen(v=>!v)} aria-expanded={open} aria-controls="ssw-historical-analysis">
      {open?'Hide':'Show'} SSW precursor history <span>7-day NOAA operational analysis · H500 and +2-PVU tropopause</span>
    </button>
    {open&&<section id="ssw-historical-analysis" className="glosea-outlook" aria-label="SSW precursor historical analysis">
      <div className="glosea-heading"><div><span className="eyebrow">STRATOSCOPE · ATMOSPHERIC PRECURSORS</span>
        <h2>Historical waveguide <span>/ observational context</span></h2></div>
        <button className="seasonal-refresh" onClick={()=>setRefresh(x=>x+1)}>Refresh analyses</button>
      </div>
      {error&&<p role="status">{error}. No historical values are inferred or replaced with forecast fields.</p>}
      {data&&<><p><strong>NOAA GFS operational analysis</strong> · 00 UTC daily · seven consecutive days ending {data.archiveThrough}.
        H500 anomalies are relative to the 1991–2020 NCEP/NCAR R1 daily mean, not current R1 observations.</p>
        <label className="seasonal-model-label">Historical date <select value={selected} onChange={e=>setSelected(Number(e.target.value))} aria-label="Select analysis date">
          {data.analyses.map((p,i)=><option key={p.date} value={i}>{p.date} 00 UTC</option>)}
        </select></label>
        {a&&<><div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(min(100%,320px),1fr))',gap:18,marginTop:16}}>
          <figure style={{minWidth:0,margin:0}}><img loading="lazy" style={{width:'100%',height:'auto'}} alt={`Northern Hemisphere 500 hPa NOAA analysis anomaly ${a.date}`} src={sswHistoryRoot+a.h500}/>
            <figcaption>500 hPa height anomaly · analysed, not forecast</figcaption></figure>
          <figure style={{minWidth:0,margin:0}}><img loading="lazy" style={{width:'100%',height:'auto'}} alt={`Northern Hemisphere +2 PVU surface potential temperature ${a.date}`} src={sswHistoryRoot+a.theta2pvu}/>
            <figcaption>Potential temperature on +2 PVU dynamical tropopause · analysed, not forecast</figcaption></figure>
        </div><p>Area-weighted H500 departures (45–75°N): North Atlantic {format(a.sectorMeanH500AnomaliesM.north_atlantic)};
          Europe {format(a.sectorMeanH500AnomaliesM.europe)}; Eurasia {format(a.sectorMeanH500AnomaliesM.eurasia)}.</p></>}
        <p><strong>Rossby-wave breaking:</strong> Not classified. These maps provide waveguide morphology for manual inspection,
          not a validated anticyclonic/cyclonic overturning diagnosis. <strong>SSW probability:</strong> Not calculated.
          Compare these observations with GEFS 100 hPa wave forcing and independently verified 10 hPa wind forecasts below/above.</p>
        <p>Analysis archive prepared {new Date(data.preparedAt).toLocaleString('en-GB',{timeZone:'UTC'})} UTC. Source snapshots are sampled at 1°.
          ERA5T back-verification is separate and normally delayed.</p>
      </>}
    </section>}
  </div>;
}
