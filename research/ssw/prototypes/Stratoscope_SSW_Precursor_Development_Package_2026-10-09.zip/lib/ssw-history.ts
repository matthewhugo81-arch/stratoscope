// Observed/analysed GFS atmospheric context. Never treat as ensemble forecast.
export const sswHistoryRoot = 'https://raw.githubusercontent.com/matthewhugo81-arch/stratoscope/forecast-data-ssw-history/';
export type SswAnalysisDay = {
  date: string;
  validTime: string;
  sourceRun: string;
  sourceClass: 'operational_analysis';
  sourceUrl: string;
  h500: string;
  theta2pvu: string;
  sectorMeanH500AnomaliesM: Record<string, number>;
  h500RangeM: [number,number];
  theta2pvuRangeK: [number,number];
  gribSha256: Record<string,string>;
  indexSha256: string;
};
export type SswHistory = {
  version: 1;
  product: 'ssw_precursor_history';
  complete: true;
  model: 'gfs';
  sourceClass: 'operational_analysis';
  archiveThrough: string;
  analyses: SswAnalysisDay[];
  h500Reference: {id:string;period:number[];sha256:string;source:string};
  rossbyWaveBreakingStatus: 'not_classified';
  sswProbability: 'not_calculated';
  preparedAt: string;
};
const hex = (s:unknown) => typeof s === 'string' && /^[a-f0-9]{64}$/.test(s);
const date = (s:unknown) => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) &&
  Number.isFinite(Date.parse(s+'T00:00:00Z')) && new Date(s+'T00:00:00Z').toISOString().slice(0,10) === s;
export function validateSswHistory(raw:unknown):SswHistory {
  const d = raw as SswHistory;
  if (!d || d.version!==1 || d.product!=='ssw_precursor_history' || d.complete!==true || d.model!=='gfs' ||
    d.sourceClass!=='operational_analysis' || d.rossbyWaveBreakingStatus!=='not_classified' ||
    d.sswProbability!=='not_calculated' || !date(d.archiveThrough) || !Array.isArray(d.analyses) ||
    d.analyses.length!==7 || d.archiveThrough!==d.analyses[6].date ||
    d.h500Reference?.id!=='ncep-ncar-r1-1991-2020-daily' ||
    d.h500Reference.period?.join(',')!=='1991,2020' || !hex(d.h500Reference.sha256) ||
    !Number.isFinite(Date.parse(d.preparedAt))) throw Error('Invalid SSW historical analysis catalogue');
  for (let i=0; i<7; i++) {
    const p=d.analyses[i];
    const stamp=p?.date+'T00:00:00.000Z';
    if(!date(p?.date) || (i>0 && Date.parse(p.date)-Date.parse(d.analyses[i-1].date)!==86400000) ||
      p.sourceClass!=='operational_analysis' || p.validTime!==stamp || p.sourceRun!==stamp ||
      p.h500!==`maps/${p.date.replaceAll('-','')}-h500.png` ||
      p.theta2pvu!==`maps/${p.date.replaceAll('-','')}-theta2pvu.png` ||
      !p.sourceUrl?.startsWith(`https://noaa-gfs-bdp-pds.s3.amazonaws.com/gfs.${p.date.replaceAll('-','')}/00/atmos/`) ||
      !hex(p.indexSha256) || !['HGT','TMP','PRES'].every(k=>hex(p.gribSha256?.[k])) ||
      !p.sectorMeanH500AnomaliesM ||
      !['north_atlantic','europe','eurasia','north_pacific','north_america','polar_cap'].every(k=>Number.isFinite(p.sectorMeanH500AnomaliesM[k])) ||
      !Array.isArray(p.h500RangeM) || p.h500RangeM.length!==2 || p.h500RangeM.some(v=>!Number.isFinite(v)) ||
      !Array.isArray(p.theta2pvuRangeK) || p.theta2pvuRangeK.length!==2 || p.theta2pvuRangeK.some(v=>!Number.isFinite(v)))
      throw Error('Incomplete SSW historical analysis for '+p?.date);
  }
  return d;
}
export async function fetchSswHistory(signal:AbortSignal):Promise<SswHistory>{
  const r=await fetch(sswHistoryRoot+'latest.json',{signal,cache:'no-cache'});
  if(!r.ok) throw Error('Historical analyses are not published yet');
  return validateSswHistory(await r.json());
}
