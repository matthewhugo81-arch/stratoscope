"""Prepare seven honest NH analysis maps as context for SSW precursor review.

NOAA GFS operational analysis at 00 UTC: 500-hPa geopotential height,
plus temperature and pressure at the +2-PVU dynamical tropopause.
Anomalies use the *existing* NCEP/NCAR R1 1991-2020 calendar-day reference,
not NCEP/NCAR R1 values for the contemporary analysis period.

This module deliberately DOES NOT diagnose Rossby wave breaking or SSW probability.
No source/model substitution: unavailable days fail the entire publication.
"""
import argparse
from datetime import datetime, date, timedelta, timezone
import hashlib
import json
from pathlib import Path
import sys
from urllib import request, error

import numpy as np

ROOT = 'https://noaa-gfs-bdp-pds.s3.amazonaws.com'
BASE = Path(__file__).resolve().parent
R_D_CP = 287.05 / 1004.0
SECTORS = {
    'north_atlantic': (300, 360, 45, 75),
    'europe': (0, 60, 45, 75),
    'eurasia': (60, 150, 45, 75),
    'north_pacific': (150, 240, 45, 75),
    'north_america': (240, 300, 45, 75),
    'polar_cap': (0, 360, 75, 90),
}


def select_inventory(raw: str, day: date) -> dict:
    """Require uniquely matched analysis messages and a following byte offset."""
    rows = [line.strip().split(':') for line in raw.splitlines() if line.strip()]
    expected = f'd={day:%Y%m%d}00'
    lookups = [('HGT', '500 mb'), ('TMP', 'PV=2e-06 (Km^2/kg/s) surface'),
               ('PRES', 'PV=2e-06 (Km^2/kg/s) surface')]
    result = {}
    for key, level in lookups:
        matching = []
        for i, row in enumerate(rows):
            if len(row) >= 6 and row[2] == expected and row[3] == key and row[4] == level and row[5] == 'anl':
                if i + 1 >= len(rows):
                    raise ValueError(f'{key} lacks a terminating index offset')
                start, stop = int(row[1]), int(rows[i + 1][1])
                if not (0 <= start < stop and stop - start < 25_000_000):
                    raise ValueError(f'Invalid {key} byte range')
                matching.append((start, stop))
        if len(matching) != 1:
            raise ValueError(f'Expected one {key} {level} analysis entry; found {len(matching)}')
        result[key] = matching[0]
    return result


def download(url: str, span: tuple[int, int] | None = None) -> bytes:
    headers = {'User-Agent': 'Stratoscope-SSW-precursor-history/1'}
    if span:
        headers['Range'] = f'bytes={span[0]}-{span[1] - 1}'
    req = request.Request(url, headers=headers)
    with request.urlopen(req, timeout=65) as resp:
        if span:
            if resp.status != 206 or not resp.headers.get('Content-Range', '').startswith(f'bytes {span[0]}-{span[1] - 1}/'):
                raise ValueError('Provider did not honour requested GRIB byte range')
        blob = resp.read()
    if span and len(blob) != span[1] - span[0]:
        raise ValueError('Incomplete GRIB byte-range response')
    return blob


def decode_grib(blob: bytes, day: date, key: str) -> np.ndarray:
    """Take exact 1-degree global samples from native 0.25-degree GFS grid."""
    import eccodes as ec
    handle = ec.codes_new_from_message(blob)
    if handle is None:
        raise ValueError('GRIB decode failed')
    try:
        get = lambda k: ec.codes_get(handle, k)
        assert get('edition') == 2 and get('gridType') == 'regular_ll'
        assert get('dataDate') == int(day.strftime('%Y%m%d')) and get('dataTime') == 0
        assert get('endStep') == 0
        # The +2-PVU surface may be masked outside the Northern Hemisphere;
        # require complete *sampled* NH cells rather than a globally absent bitmap.
        expected = {'HGT': ('gh', 100), 'TMP': ('t', 109), 'PRES': ('pres', 109)}
        short_name, level_type = expected[key]
        assert get('shortName') == short_name and get('typeOfFirstFixedSurface') == level_type
        if key == 'HGT':
            assert get('level') == 500 and not get('bitmapPresent')
        nx, ny = int(get('Ni')), int(get('Nj'))
        dx = float(get('iDirectionIncrementInDegrees'))
        dy = float(get('jDirectionIncrementInDegrees')) * (1 if get('jScansPositively') else -1)
        lon0 = float(get('longitudeOfFirstGridPointInDegrees'))
        lat0 = float(get('latitudeOfFirstGridPointInDegrees'))
        assert nx == 1440 and ny == 721 and dx == .25 and abs(dy) == .25
        assert not get('iScansNegatively') and not get('jPointsAreConsecutive')
        lat_indices = (90 - np.arange(61) - lat0) / dy
        lon_indices = ((np.arange(360) - lon0 + 720) % 360) / dx
        assert np.allclose(lat_indices, np.rint(lat_indices), atol=1e-8)
        assert np.allclose(lon_indices, np.rint(lon_indices), atol=1e-8)
        assert lat_indices.min() >= 0 and lat_indices.max() < ny
        values = ec.codes_get_values(handle).reshape(ny, nx)
        subset = values[np.ix_(lat_indices.astype(int), lon_indices.astype(int))].copy()
        assert subset.shape == (61, 360) and np.isfinite(subset).all()
        assert np.max(np.abs(subset)) < 1.e10
        return subset
    finally:
        ec.codes_release(handle)


def potential_temperature(temperature_k: np.ndarray, pressure_pa: np.ndarray) -> np.ndarray:
    if temperature_k.shape != pressure_pa.shape or not np.isfinite(temperature_k).all() or not np.isfinite(pressure_pa).all():
        raise ValueError('Incomplete +2 PVU temperature and pressure')
    if not (np.all((temperature_k > 150) & (temperature_k < 350)) and
            np.all((pressure_pa > 3500) & (pressure_pa < 100000))):
        raise ValueError('Unphysical +2 PVU atmospheric field')
    return temperature_k * (100000.0 / pressure_pa) ** R_D_CP


def latitude_weighted_means(a: np.ndarray) -> dict:
    if a.shape != (61, 360):
        raise ValueError('Expected 90N-30N/0E-359E 1-degree grid')
    d = {}
    for label, (lo, hi, lat_lo, lat_hi) in SECTORS.items():
        rows = slice(90 - lat_hi, 91 - lat_lo)
        sample = a[rows, lo:hi]
        weight = np.cos(np.deg2rad(90 - np.arange(90 - lat_hi, 91 - lat_lo)))[:, None]
        d[label] = round(float((sample * weight).sum() / (weight.sum() * (hi - lo))), 1)
    return d


def polar_plot(path: Path, value: np.ndarray, field: str, day: date, coast_path: Path):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.colors import TwoSlopeNorm
    lon = np.deg2rad(np.arange(360))[None, :]
    r = ((90 - np.arange(90, 29, -1)) / 60.0)[:, None]
    x, y = r * np.sin(lon), -r * np.cos(lon)
    lon_edges = np.deg2rad(np.arange(-.5, 360.5, 1))[None, :]
    r_edges = np.maximum(0, (90 - np.arange(90.5, 29.0, -1)) / 60)[:, None]
    edge_x, edge_y = r_edges * np.sin(lon_edges), -r_edges * np.cos(lon_edges)
    assert edge_x.shape == (62, 361)
    fig, ax = plt.subplots(figsize=(6.5, 6.1), dpi=130)
    fig.patch.set_facecolor('#0c1624'); ax.set_facecolor('#0c1624')
    if field == 'h500':
        cs = ax.pcolormesh(edge_x, edge_y, value, shading='flat', cmap='RdBu_r',
                           norm=TwoSlopeNorm(vmin=-300, vcenter=0, vmax=300), rasterized=True)
        title = '500 hPa geopotential height anomaly'
        cblabel = 'm relative to NCEP/NCAR R1 1991–2020 daily mean'
    else:
        cs = ax.pcolormesh(edge_x, edge_y, value, shading='flat', cmap='turbo', vmin=280, vmax=420, rasterized=True)
        if np.nanmin(value) < 350 and np.nanmax(value) > 315:
            contours = ax.contour(x, y, value, levels=[315, 330, 350], colors='#ffffff',
                                  linewidths=.75, alpha=.75)
            ax.clabel(contours, fontsize=7, fmt='%d K', inline=True)
        title = 'Potential temperature on +2-PVU surface'
        cblabel = 'K; not direct PV on an isentropic surface'
    if coast_path.exists():
        coastline = json.loads(coast_path.read_text())
        for feature in coastline.get('features', []):
            geom = feature.get('geometry', {})
            lines = [geom['coordinates']] if geom.get('type') == 'LineString' else geom.get('coordinates', [])
            for line in lines:
                section = []
                for longitude, latitude in line:
                    if latitude < 30:
                        if len(section) > 1:
                            ax.plot(*zip(*section), color='#e1e7ec', lw=.38, alpha=.55)
                        section = [];continue
                    ang = np.deg2rad(longitude);rr = (90 - latitude) / 60
                    q = (rr * np.sin(ang), -rr * np.cos(ang))
                    if section and np.linalg.norm(np.array(q) - np.array(section[-1])) > .4:
                        if len(section) > 1:
                            ax.plot(*zip(*section), color='#e1e7ec', lw=.38, alpha=.55)
                        section = []
                    section.append(q)
                if len(section) > 1:
                    ax.plot(*zip(*section), color='#e1e7ec', lw=.38, alpha=.55)
    for lat in [30, 45, 60, 75]:
        ax.add_patch(plt.Circle((0, 0), (90-lat)/60, ec='#ffffff', fill=False, alpha=.17, lw=.6))
    ax.add_patch(plt.Circle((0, 0), 1, ec='#dae6ee', fill=False, alpha=.5, lw=.6))
    ax.set(xlim=(-1.05,1.05),ylim=(-1.05,1.05),aspect='equal');ax.axis('off')
    fig.suptitle(f'{title}  |  {day.isoformat()} 00 UTC', color='white', fontsize=11, fontweight='bold')
    cb=fig.colorbar(cs, ax=ax, location='bottom', fraction=.055, pad=.03, shrink=.80)
    cb.set_label(cblabel, color='#dce8f2', fontsize=8)
    cb.ax.tick_params(colors='#dce8f2',labelsize=7)
    path.parent.mkdir(parents=True,exist_ok=True)
    fig.savefig(path, dpi=130, facecolor=fig.get_facecolor(), bbox_inches='tight')
    plt.close(fig)


def prepare_day(day: date, reference: np.ndarray, reference_meta: dict, output: Path, coast: Path):
    sys.path.insert(0, str(BASE))
    import vortex_context
    base = f'{ROOT}/gfs.{day:%Y%m%d}/00/atmos/gfs.t00z.pgrb2.0p25.anl'
    idx = download(base + '.idx').decode('utf-8')
    spans = select_inventory(idx, day)
    decoded, hashes = {}, {}
    for key, span in spans.items():
        blob = download(base, span)
        hashes[key] = hashlib.sha256(blob).hexdigest()
        decoded[key] = decode_grib(blob, day, key)
    height = decoded['HGT'];theta = potential_temperature(decoded['TMP'], decoded['PRES'])
    if not (np.all(height > 3500) and np.all(height < 6500)):
        raise ValueError('Invalid 500-hPa geopotential height')
    target = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
    reference_day = vortex_context.daily_reference(reference, target)
    anomaly = height - vortex_context.interpolate_reference(reference_day)
    if np.max(np.abs(anomaly)) >= 1500:
        raise ValueError('Unphysical 500-hPa anomaly')
    if not (np.nanmin(theta) > 200 and np.nanmax(theta) < 600):
        raise ValueError('Unphysical +2-PVU potential temperature')
    label = day.strftime('%Y%m%d')
    hm, tm = f'maps/{label}-h500.png', f'maps/{label}-theta2pvu.png'
    polar_plot(output/hm, anomaly, 'h500', day, coast)
    polar_plot(output/tm, theta, 'theta', day, coast)
    return {'date': day.isoformat(), 'validTime': target.isoformat(timespec='milliseconds').replace('+00:00','Z'),
            'sourceRun': target.isoformat(timespec='milliseconds').replace('+00:00','Z'),
            'sourceClass': 'operational_analysis', 'sourceUrl': base,
            'h500': hm, 'theta2pvu': tm,
            'sectorMeanH500AnomaliesM': latitude_weighted_means(anomaly),
            'h500RangeM': [round(float(anomaly.min()),1),round(float(anomaly.max()),1)],
            'theta2pvuRangeK': [round(float(theta.min()),1),round(float(theta.max()),1)],
            'gribSha256': hashes, 'indexSha256': hashlib.sha256(idx.encode()).hexdigest()}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--end-date',type=date.fromisoformat,default=datetime.now(timezone.utc).date()-timedelta(days=1))
    parser.add_argument('--days',type=int,default=7)
    args=parser.parse_args()
    assert 1<=args.days<=14
    sys.path.insert(0, str(BASE))
    import vortex_context
    reference,meta = vortex_context.load_reference()
    result=[]
    # Transactional publication: a missing or partial analysis never masquerades as a complete week.
    for days_ago in reversed(range(args.days)):
        day=args.end_date-timedelta(days=days_ago)
        item=prepare_day(day,reference,meta,args.output,BASE.parent/'public/coastline.json')
        result.append(item)
        print(f"PREPARED {day} 00 UTC H500 and +2PVU theta",flush=True)
    latest={'version':1,'product':'ssw_precursor_history','complete':True,
        'source':'NOAA GFS 0.25deg operational analysis, native grid sampled at 1 degree',
        'sourceClass':'operational_analysis','archiveThrough':result[-1]['date'],
        'analyses':result,'model':'gfs','sampling':'00 UTC each day',
        'region':'Northern Hemisphere 30–90N, 0–359E',
        'grid':{'nx':360,'ny':61,'lat0':90,'lon0':0,'dx':1,'dy':-1},
        'h500Reference':{'id':meta['id'],'period':meta['period'],'sha256':meta['sha256'],
            'source':meta['source']},
        'theta2pvuDefinition':'theta=T_K*(100000/P_Pa)^(287.05/1004); NOAA +2 PVU surface; Kelvin',
        'rossbyWaveBreakingStatus':'not_classified',
        'rossbyWaveBreakingNote':'Potential-temperature morphology on +2 PVU provides context; no objective anticyclonic/cyclonic classification yet.',
        'sswProbability':'not_calculated',
        'preparedAt':datetime.now(timezone.utc).isoformat()}
    (args.output/'latest.json').write_text(json.dumps(latest,separators=(',',':'))+'\n',encoding='utf-8')
    print('COMPLETE 7-DAY NOAA OPERATIONAL ANALYSIS CONTEXT',len(result),flush=True)

if __name__=='__main__':main()
