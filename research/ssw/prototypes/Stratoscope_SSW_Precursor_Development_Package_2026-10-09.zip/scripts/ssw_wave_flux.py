"""Member-first k=1/k=2 decomposition of GEFS 100 hPa eddy heat flux.

This diagnostic does not change the existing production heat-flux workflow.
Input: complete 31-member GEFS fields (member, latitude 90->0N, longitude 0->359E)
with v in m/s and T in Celsius (differences are Kelvin).
"""
import numpy as np


def decompose_100hpa(v:np.ndarray, temperature:np.ndarray) -> dict[str,list[float]]:
    """Area-mean 45–75N total eddy v'T' plus zonal waves k1/k2 and residual.

    FFT is along longitude only; conserve signed full covariance, including
    negative flux. Compute EACH member before ensemble averages to preserve phases.
    """
    if v.shape!=(31,91,360) or temperature.shape!=v.shape:
        raise ValueError('Expected full 31-member, 91-latitude, 360-longitude fields')
    if not (np.isfinite(v).all() and np.isfinite(temperature).all()):
        raise ValueError('Non-finite GEFS fields')
    v=v[:,15:46,:].astype(float)
    t=temperature[:,15:46,:].astype(float)
    vp=v-v.mean(axis=-1,keepdims=True)
    tp=t-t.mean(axis=-1,keepdims=True)
    total=(vp*tp).mean(axis=-1)
    vf=np.fft.rfft(vp,axis=-1)
    tf=np.fft.rfft(tp,axis=-1)
    nk=vp.shape[-1]
    k1=2*np.real(vf[...,1]*np.conj(tf[...,1]))/nk**2
    k2=2*np.real(vf[...,2]*np.conj(tf[...,2]))/nk**2
    remaining=total-k1-k2
    lat=np.arange(75,44,-1,dtype=float)
    weights=np.sin(np.deg2rad(np.minimum(75,lat+.5)))-np.sin(np.deg2rad(np.maximum(45,lat-.5)))
    def weighted(a):return np.round(np.sum(a*weights[None,:],axis=1)/weights.sum(),6).tolist()
    return {'total':weighted(total),'wave1':weighted(k1),'wave2':weighted(k2),'higherWavesAndResidual':weighted(remaining)}
