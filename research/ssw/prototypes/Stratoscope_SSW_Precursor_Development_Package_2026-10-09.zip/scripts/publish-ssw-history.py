"""Publish only completed, source-validated daily SSW context to a data-only branch."""
import argparse
import json
import os
from pathlib import Path
import subprocess


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    root=args.output.resolve()
    repository=os.environ['GITHUB_REPOSITORY']
    assert repository=='matthewhugo81-arch/stratoscope'
    assert os.environ.get('GITHUB_REPOSITORY_VISIBILITY')=='public'
    manifest=json.loads((root/'latest.json').read_text())
    assert manifest['product']=='ssw_precursor_history' and manifest['complete'] and len(manifest['analyses'])==7
    assert manifest['sourceClass']=='operational_analysis' and manifest['rossbyWaveBreakingStatus']=='not_classified'
    for a in manifest['analyses']:
        for k in ['h500','theta2pvu']:
            p=(root/a[k]).resolve()
            assert p.is_relative_to(root) and p.exists() and p.suffix=='.png'
    branch='forecast-data-ssw-history'
    def git(*args):
        return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
    git('init','-b',branch)
    git('config','user.name','github-actions[bot]')
    git('config','user.email','41898282+github-actions[bot]@users.noreply.github.com')
    git('remote','add','origin','https://github.com/'+repository+'.git')
    old=git('ls-remote','origin','refs/heads/'+branch)
    old_sha=old.split()[0] if old else ''
    if old_sha:
        git('fetch','--depth=1','origin',branch)
        previous=json.loads(git('show',old_sha+':latest.json'))
        if manifest['archiveThrough'] < previous['archiveThrough']:
            raise ValueError('Refusing to replace newer historical analysis with older issue')
    (root/'README.md').write_text('Generated, source-validated Stratoscope seven-day NOAA GFS operational analysis. Not an ERA5 reanalysis or SSW prediction. Source code is on main.\n')
    git('add','.')
    git('commit','-m','Prepare SSW precursor context through '+manifest['archiveThrough'])
    git('push',f'--force-with-lease=refs/heads/{branch}:{old_sha}','origin',f'HEAD:refs/heads/{branch}')
    print('PUBLISHED',manifest['archiveThrough'],branch,flush=True)

if __name__=='__main__':main()
