# Stratoscope SSW precursor history — installation and validation

**Status:** first-stage implementation, tested offline on synthetic data. NOAA operational GRIB and GitHub Actions have not been exercised live; do not represent the seven-day dataset as already published.

## Installation

Copy the following paths to the root of the existing `matthewhugo81-arch/stratoscope` repository (the bundled paths mirror the source tree):

- `scripts/prepare-ssw-history.py`
- `scripts/publish-ssw-history.py`
- `scripts/ssw_wave_flux.py` (member-wise k1/k2 analysis helper; **not** yet wired to the production heat-flux series)
- `lib/ssw-history.ts`
- `components/ssw-history.tsx`
- `tests/test_ssw_history.py`
- `tests/test_ssw_wave_flux.py`
- `.github/workflows/prepare-ssw-history.yml`
- `docs/SSW_PRECURSOR_METHOD.md`

In `app/page.tsx`, include an additional import next to the other chart components:

```tsx
import {SswHistory} from '@/components/ssw-history';
```

Place this component directly before `<NorthernComparison/>`:

```tsx
<SswHistory/>
```

Do not remove or replace any current Stratoscope component or forecast-data branch.

## Verify before merge or scheduled runs

1. Run the unit tests (`python -m unittest discover -s tests -p 'test_ssw_*.py'`).
2. Run the existing checks (`npm exec -- tsc --noEmit`, `node --test tests/*.test.mjs`, `npm run build:pages`).
3. Execute **Prepare SSW precursor history** by `workflow_dispatch` on GitHub. Confirm it receives seven actual 00 UTC GFS analysis cycles and publishes both PNGs per date. Check S3 `.idx` matching, GRIB field identity, grid ordering, units, calendar-day anomaly reference, and the resulting maps. An incomplete source week must fail without publishing a substitute.
4. Open the live panel, verify the archive-through stamp and sector anomalies. If the workflow fails, investigate live source availability rather than masking the error; only after successful publication should the analysis be considered operational.
5. The workflow is scheduled for 10:19 UTC daily once merged. The 10:19 value is an implementation choice, not a promise that the provider publishes by then. Add a later retry if necessary.

The component checks that all seven analyses are consecutive days with source hashes and defined fields; it shows no RWB classification or SSW probability. The separate *forecast* and *reanalysis* pipelines remain unchanged.
